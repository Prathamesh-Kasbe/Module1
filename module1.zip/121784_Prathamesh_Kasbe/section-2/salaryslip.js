function generateSlip()
	{
		
		var g=document.salary.gross.value;
	    var net=0;
		var i=0;
		if(g<180000)
		{
			i=0;
			net=g;
		}
		else 
			if(g>=180000 && g<300000)
			{
				i=g*0.1;
				net=g-i;
			}
			else
				if(g>=300001 && g<500000)
				{
					i=g*0.2;
				net=g-i;
				}
				else
				{
					i=g*0.3;
				net=g-i;
				}
		
 myWindow = open('','mywin','height=800,width=800,scrollbars=yes');

 myWindow.document.writeln("<html><head><title>Salary slip</title></head><body>");
 myWindow.document.writeln("<center><h1>Salary slip</h1><br /><br /><br />");
 myWindow.document.writeln("<table border='1'><tr>");
 
 myWindow.document.writeln("<td><b>Net Salary</b></td>");
 myWindow.document.writeln("<td><b>Income Tax </b></td>");
 myWindow.document.writeln("<td><b>Employee Name</b></td>");
  
 myWindow.document.writeln("</tr><tr><td>"+net+"</td>");
  myWindow.document.writeln("<td>"+i+"</td>");
 myWindow.document.writeln("<td>"+document.salary.title.value+" "+document.salary.fname.value+" "+document.salary.lname.value+"</td>");
 
 myWindow.document.writeln("</tr></table></center></body></html>");
 myWindow.document.close();
	}
		